# Инструкция по подключению ZigbeeDud к Home Assistant OS (HAOS)

Умный автоматический выключатель / реле **ZigbeeDud** на базе микроконтроллера **ESP32-C5 mini v1** (с нативным радиомодулем Zigbee 3.0 IEEE 802.15.4) предназначен для интеграции в систему **Home Assistant OS (HAOS)** через **ZHA** или **Zigbee2MQTT**.

---

## 1. Спецификация Zigbee устройства

- **Модель (Model ID):** `SBS3-C5-PowerRelay`
- **Производитель (Manufacturer):** `ZigbeeDud`
- **Профиль:** Home Automation (`0x0104`)
- **Основной Endpoint:** `0x01` (Реле On/Off `0x0006`, Энергомониторинг `0x0B04`, Учет энергии `0x0702`)
- **Температурный Endpoint:** `0x02` (Датчик температуры DS18B20 `0x0402`)

### Аппаратная привязка контактов (ESP32-C5 mini v1)
- **GPIO 15:** Силовое реле (Active LOW / инвертированное)
- **GPIO 5:** 1-Wire шина датчика температуры DS18B20 (линия DQ с подтяжкой 4.7 кОм)
- **GPIO 8:** BL0937 CF (импульсы активной мощности)
- **GPIO 6:** BL0937 CF1 (импульсы напряжения / тока)
- **GPIO 7:** BL0937 SEL (выбор канала: 0 = напряжение, 1 = ток)
- **GPIO 10:** Красный светодиод статуса (Active LOW)
- **GPIO 9:** Кнопка BOOT / Сопряжения (замыкание на GND, удержание 5 сек)
- **GPIO 12 / 14:** UART RX/TX (BL0937)

---

## 2. Режим сопряжения (Pairing Mode)

1. Подайте питание на выключатель.
2. Зажмите кнопку на **GPIO 9** (кнопка BOOT) на **5 секунд**.
3. Красный светодиод статуса на **GPIO 10** начнет часто мигать (4 раза в секунду), сигнализируя об очистке привязок NVS и переходе в режим сопряжения Zigbee.
4. В Home Assistant откройте поиск новых устройств (в ZHA или Zigbee2MQTT).
5. После сопряжения светодиод перестает мигать.

---

## 3. Подключение через Home Assistant ZHA (Zigbee Home Automation)

ZHA поддерживает устройство стандартными кластерами ZCL "из коробки" без дополнительных драйверов:

1. В Home Assistant откройте **Настройки** -> **Устройства и службы**.
2. В блоке **Zigbee Home Automation** нажмите **Настроить** -> **Добавить устройство**.
3. Переведите выключатель в режим сопряжения (удержание кнопки 5 секунд).
4. Home Assistant автоматически обнаружит:
   - **Устройство:** `ZigbeeDud SBS3-C5-PowerRelay`
   - **Сущности:**
     - `switch.sbs3-c5-powerrelay_switch` (Управление нагрузкой)
     - `sensor.sbs3-c5-powerrelay_temperature` (Температура DS18B20, °C)
     - `sensor.sbs3-c5-powerrelay_power` (Активная мощность, W)
     - `sensor.sbs3-c5-powerrelay_voltage` (Напряжение сети, V)
     - `sensor.sbs3-c5-powerrelay_current` (Ток нагрузки, A)
     - `sensor.sbs3-c5-powerrelay_energy` (Суммарная энергия, kWh)

---

## 4. Подключение через Zigbee2MQTT (Z2M)

Для точной калибровки и передачи данных используется готовый конвертер из каталога `zigbee2mqtt/`:

1. Скопируйте файл `zigbee2mqtt/zigbee2mqtt_converter.js` в каталог Home Assistant:
   ```
   /config/zigbee2mqtt/zigbee2mqtt_converter.js
   ```
2. В файле `/config/zigbee2mqtt/configuration.yaml` укажите:
   ```yaml
   external_converters:
     - zigbee2mqtt_converter.js
   ```
3. Перезапустите аддон Zigbee2MQTT.
4. Нажмите **«Разрешить подключение» (Permit join)** в веб-интерфейсе Z2M и удерживайте сервисную кнопку на выключателе 5 секунд.
5. Устройство добавится с полным списком Exposes (включение реле, датчики мощности, напряжения, тока, энергии и температуры).

---

## 5. Добавление в панель «Энергия» (Home Assistant Energy Dashboard)

1. Откройте **Настройки** -> **Панели управления** -> **Энергия**.
2. В секции **Индивидуальные устройства (Individual Devices)** нажмите **Добавить устройство**.
3. Выберите сенсор расхода: `sensor.sbs3-c5-powerrelay_energy`.
4. Сохраните. Home Assistant начнет автоматически строить графики потребления в кВт⋅ч.

---

## 6. Пример карточки Lovelace Dashboard (YAML)

```yaml
type: vertical-stack
cards:
  - type: entities
    title: Умный автомат ZigbeeDud (SBS3-C5-PowerRelay)
    entities:
      - entity: switch.sbs3-c5-powerrelay_switch
        name: Силовое реле
      - entity: sensor.sbs3-c5-powerrelay_power
        name: Мощность (W)
      - entity: sensor.sbs3-c5-powerrelay_voltage
        name: Напряжение (V)
      - entity: sensor.sbs3-c5-powerrelay_current
        name: Ток (A)
      - entity: sensor.sbs3-c5-powerrelay_energy
        name: Энергия (кВт⋅ч)
      - entity: sensor.sbs3-c5-powerrelay_temperature
```

---

## 7. Диагностика неисправностей (Красный LED горит постоянно, нет реакции на кнопку)

Если при подаче питания на модуле горит постоянный красный светодиод и нет реакции на нажатие кнопки:

1. **Красный светодиод питания (Power LED):** На платах ESP32-C5 mini v1 красный светодиод распаян аппаратно между 3.3V и GND через резистор. Он горит **всегда**, пока подано питание. Программный светодиод статуса подключен к **GPIO 10** (Active LOW).
2. **Застревание в режиме Bootloader (GPIO 9 = LOW):** Пин **GPIO 9** является strapping-выводом BOOT. Если кнопка при включении замкнута на GND или на линии есть утечка, ESP32 переходит в режим загрузчика (ROM Download Mode) вместо запуска прошивки.
   - *Решение:* Отпустите кнопку, нажмите однократно аппаратную кнопку **RST** на плате.
3. **Brownout Reset при старте Zigbee радио:** При включении радиомодуля IEEE 802.15.4 происходит бросок тока до 300 мА. При слабом питании плата бесконечно перезагружается.
   - *Решение:* Используйте надежный блок питания 5V (не менее 1А) и подключите электролитический конденсатор 220–470 мкФ на шину 3.3V.
4. **Проверка через Web Serial монитор:** Откройте монитор порта в приложении (115200 бод) и нажмите «Сброс EN». В логе должно быть: `Pins initialized: Relay=GPIO15, LED=GPIO10, Button=GPIO9`.
5. **Сбой «Zigbee stack assertion failed zcl_general_commands.c:608»:** Если в консоли возникает `abort() was called at PC ... zb_assert`, это вызвано вызовом `esp_zb_zcl_set_attribute_val()` до регистрации эндпоинтов (`esp_zb_device_register`) или без мьютекса `esp_zb_lock_acquire()`. В обновленной версии прошивки инициализация реле в `app_main` полностью отделена от ZCL-атрибутов, а стек защищен флагом `s_zb_initialized`.
