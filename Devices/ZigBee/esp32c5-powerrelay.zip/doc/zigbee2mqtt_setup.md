# Подключение ZigbeeDud к Zigbee2MQTT в Home Assistant OS

## Установка внешнего конвертера
1. Скопируйте файл `zigbee2mqtt_converter.js` в каталог Home Assistant:
   `/config/zigbee2mqtt/zigbee2mqtt_converter.js`
2. В файле конфигурации `/config/zigbee2mqtt/configuration.yaml` добавьте:
   ```yaml
   external_converters:
     - zigbee2mqtt_converter.js
   ```
3. Перезапустите Zigbee2MQTT.
4. Включите **Permit join** и удерживайте кнопку (GPIO 9) 5 секунд для сопряжения.
