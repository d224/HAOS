@echo off
chcp 65001 >nul
echo ==============================================================
echo [ZigbeeDud] Локальная сборка проекта для ESP32-C5 mini v1
echo Каталог проекта: C:\D224\esp\ZigbeeDud
echo ==============================================================

:: Проверка переменной IDF_PATH
if defined IDF_PATH (
    echo [*] Найдено установленное окружение IDF_PATH=%IDF_PATH%
    goto :run_build
)

:: Поиск установленной среды в C:\Espressif и C:\esp
if exist "C:\Espressif\idf_cmd_init.bat" (
    echo [*] Подключение среды из C:\Espressif\idf_cmd_init.bat...
    call "C:\Espressif\idf_cmd_init.bat"
    goto :run_build
)

if exist "C:\esp\esp-idf\export.bat" (
    echo [*] Подключение среды из C:\esp\esp-idf\export.bat...
    call "C:\esp\esp-idf\export.bat"
    goto :run_build
)

if exist "C:\Espressif\frameworks\esp-idf\export.bat" (
    echo [*] Подключение среды из C:\Espressif\frameworks\esp-idf\export.bat...
    call "C:\Espressif\frameworks\esp-idf\export.bat"
    goto :run_build
)

echo.
echo [!] ОШИБКА: Среда ESP-IDF не обнаружена!
echo Убедитесь, что ESP-IDF установлена в C:\Espressif или C:\esp\esp-idf.
pause
exit /b 1

:run_build
echo [*] Настройка целевого чипа: esp32c5
call idf.py set-target esp32c5

echo.
echo [*] Компиляция микропрограммы ZigbeeDud...
call idf.py build

if %ERRORLEVEL% EQU 0 (
    echo.
    echo ==============================================================
    echo [УСПЕХ] Проект ZigbeeDud успешно скомпилирован!
    echo Бинарные файлы созданы в каталоге build\
    echo.
    echo Для прошивки в ESP32-C5 выполните:
    echo   flash_windows.bat COM3
    echo (укажите ваш COM-порт вместо COM3)
    echo ==============================================================
) else (
    echo.
    echo [!] Ошибка при компиляции проекта! Проверьте журнал ошибок выше.
)

pause
