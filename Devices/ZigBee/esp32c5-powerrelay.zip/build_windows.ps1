# PowerShell build script for ZigbeeDud on Windows
$ErrorActionPreference = "Stop"
Write-Host "==============================================================" -ForegroundColor Cyan
Write-Host "[ZigbeeDud] Локальная сборка проекта для ESP32-C5 mini v1" -ForegroundColor Yellow
Write-Host "Каталог проекта: C:\D224\esp\ZigbeeDud" -ForegroundColor Gray
Write-Host "==============================================================" -ForegroundColor Cyan

# Check for ESP-IDF
if (-not $env:IDF_PATH) {
    if (Test-Path "C:\Espressif\idf_cmd_init.bat") {
        Write-Host "[*] Активация среды C:\Espressif..." -ForegroundColor Green
        cmd.exe /c "C:\Espressif\idf_cmd_init.bat && idf.py set-target esp32c5 && idf.py build"
        exit
    } elseif (Test-Path "C:\esp\esp-idf\export.ps1") {
        Write-Host "[*] Активация среды C:\esp\esp-idf\export.ps1..." -ForegroundColor Green
        . "C:\esp\esp-idf\export.ps1"
    } elseif (Test-Path "C:\Espressif\frameworks\esp-idf\export.ps1") {
        Write-Host "[*] Активация среды C:\Espressif\frameworks\esp-idf\export.ps1..." -ForegroundColor Green
        . "C:\Espressif\frameworks\esp-idf\export.ps1"
    } else {
        Write-Host "[!] ESP-IDF не найдена в C:\Espressif или C:\esp" -ForegroundColor Red
        exit 1
    }
}

Write-Host "[*] Настройка целевого чипа: esp32c5" -ForegroundColor Yellow
idf.py set-target esp32c5

Write-Host "[*] Компиляция проекта..." -ForegroundColor Yellow
idf.py build

Write-Host "[УСПЕХ] Проект успешно собран!" -ForegroundColor Green
