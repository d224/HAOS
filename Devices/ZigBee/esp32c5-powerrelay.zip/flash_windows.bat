@echo off
chcp 65001 >nul
echo ==============================================================
echo [ZigbeeDud] Прошивка ESP32-C5 mini v1 через USB-UART
echo ==============================================================

if "%~1"=="" (
    echo.
    echo Введите номер COM-порта ESP32-C5 (например, COM3 или COM4):
    set /p COMPORT="COM-порт: "
) else (
    set COMPORT=%~1
)

if "%COMPORT%"=="" (
    echo [!] Порт не указан. Завершение.
    pause
    exit /b 1
)

:: Проверка переменной IDF_PATH
if not defined IDF_PATH (
    if exist "C:\Espressif\idf_cmd_init.bat" call "C:\Espressif\idf_cmd_init.bat"
    if exist "C:\esp\esp-idf\export.bat" call "C:\esp\esp-idf\export.bat"
    if exist "C:\Espressif\frameworks\esp-idf\export.bat" call "C:\Espressif\frameworks\esp-idf\export.bat"
)

echo [*] Запуск прошивки на %COMPORT% и открытие терминала мониторинга...
echo [*] Для выхода из монитора нажмите: Ctrl + ]
call idf.py -p %COMPORT% flash monitor
pause
