/**
 * @file ds18b20_driver.h
 * @brief High-precision 1-Wire DS18B20 digital thermometer driver for ESP32-C5
 */

#pragma once

#include "esp_err.h"
#include "driver/gpio.h"

#ifdef __cplusplus
extern "C" {
#endif

esp_err_t ds18b20_init(gpio_num_t pin);
esp_err_t ds18b20_read_temp(float *temperature);

#ifdef __cplusplus
}
#endif
