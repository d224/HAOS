/**
 * @file ds18b20_driver.c
 * @brief 1-Wire timing and DS18B20 scratchpad decoder with CRC check
 */

#include "ds18b20_driver.h"
#include "esp_rom_sys.h"
#include "esp_log.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

static gpio_num_t s_pin = GPIO_NUM_NC;
static const char *TAG = "DS18B20";

static inline void delay_us(uint32_t us) {
    esp_rom_delay_us(us);
}

static esp_err_t onewire_reset(void) {
    gpio_set_direction(s_pin, GPIO_MODE_OUTPUT);
    gpio_set_level(s_pin, 0);
    delay_us(480);

    gpio_set_direction(s_pin, GPIO_MODE_INPUT);
    delay_us(70);

    int presence = gpio_get_level(s_pin);
    delay_us(410);

    return (presence == 0) ? ESP_OK : ESP_FAIL;
}

static void onewire_write_bit(int bit) {
    gpio_set_direction(s_pin, GPIO_MODE_OUTPUT);
    gpio_set_level(s_pin, 0);
    if (bit) {
        delay_us(6);
        gpio_set_direction(s_pin, GPIO_MODE_INPUT);
        delay_us(64);
    } else {
        delay_us(60);
        gpio_set_direction(s_pin, GPIO_MODE_INPUT);
        delay_us(10);
    }
}

static int onewire_read_bit(void) {
    gpio_set_direction(s_pin, GPIO_MODE_OUTPUT);
    gpio_set_level(s_pin, 0);
    delay_us(3);
    gpio_set_direction(s_pin, GPIO_MODE_INPUT);
    delay_us(10);
    int bit = gpio_get_level(s_pin);
    delay_us(50);
    return bit;
}

static void onewire_write_byte(uint8_t byte) {
    for (int i = 0; i < 8; i++) {
        onewire_write_bit(byte & 0x01);
        byte >>= 1;
    }
}

static uint8_t onewire_read_byte(void) {
    uint8_t byte = 0;
    for (int i = 0; i < 8; i++) {
        if (onewire_read_bit()) {
            byte |= (1 << i);
        }
    }
    return byte;
}

static uint8_t crc8(const uint8_t *data, uint8_t len) {
    uint8_t crc = 0;
    for (uint8_t i = 0; i < len; i++) {
        uint8_t byte = data[i];
        for (uint8_t b = 0; b < 8; b++) {
            uint8_t mix = (crc ^ byte) & 0x01;
            crc >>= 1;
            if (mix) crc ^= 0x8C;
            byte >>= 1;
        }
    }
    return crc;
}

esp_err_t ds18b20_init(gpio_num_t pin) {
    s_pin = pin;
    gpio_config_t cfg = {
        .pin_bit_mask = (1ULL << pin),
        .mode = GPIO_MODE_INPUT,
        .pull_up_en = GPIO_PULLUP_ENABLE, // Internal pullup auxiliary
        .pull_down_en = GPIO_PULLDOWN_DISABLE,
        .intr_type = GPIO_INTR_DISABLE
    };
    gpio_config(&cfg);

    if (onewire_reset() == ESP_OK) {
        ESP_LOGI(TAG, "1-Wire DS18B20 presence detected on GPIO %d", pin);
        return ESP_OK;
    }
    ESP_LOGW(TAG, "No 1-Wire device detected on GPIO %d (check 4.7k pull-up resistor)", pin);
    return ESP_FAIL;
}

static portMUX_TYPE s_mux = portMUX_INITIALIZER_UNLOCKED;

esp_err_t ds18b20_read_temp(float *temperature) {
    if (s_pin == GPIO_NUM_NC) return ESP_ERR_INVALID_STATE;

    portENTER_CRITICAL(&s_mux);
    if (onewire_reset() != ESP_OK) {
        portEXIT_CRITICAL(&s_mux);
        return ESP_ERR_TIMEOUT;
    }
    onewire_write_byte(0xCC); // Skip ROM
    onewire_write_byte(0x44); // Start conversion
    portEXIT_CRITICAL(&s_mux);

    // 12-bit conversion requires up to 750ms
    vTaskDelay(pdMS_TO_TICKS(750));

    portENTER_CRITICAL(&s_mux);
    if (onewire_reset() != ESP_OK) {
        portEXIT_CRITICAL(&s_mux);
        return ESP_ERR_TIMEOUT;
    }
    onewire_write_byte(0xCC); // Skip ROM
    onewire_write_byte(0xBE); // Read scratchpad

    uint8_t scratchpad[9];
    for (int i = 0; i < 9; i++) {
        scratchpad[i] = onewire_read_byte();
    }
    portEXIT_CRITICAL(&s_mux);

    if (crc8(scratchpad, 8) != scratchpad[8]) {
        ESP_LOGW(TAG, "DS18B20 CRC8 mismatch");
        return ESP_ERR_INVALID_CRC;
    }

    int16_t raw = (scratchpad[1] << 8) | scratchpad[0];
    *temperature = (float)raw / 16.0f;
    return ESP_OK;
}
