/**
 * @file power_meter.c
 * @brief BL0937 Pulse Counter Driver (CF: Power, CF1: V/I, SEL: Mode)
 */

#include "power_meter.h"
#include "driver/gpio.h"
#include "esp_timer.h"
#include "esp_log.h"
#include <string.h>

static const char *TAG = "BL0937_METER";

static gpio_num_t s_cf_pin = GPIO_NUM_NC;
static gpio_num_t s_cf1_pin = GPIO_NUM_NC;
static gpio_num_t s_sel_pin = GPIO_NUM_NC;

static volatile int64_t s_last_cf_time = 0;
static volatile int64_t s_cf_period_us = 0;
static volatile uint32_t s_cf_pulse_count = 0;

static volatile int64_t s_last_cf1_time = 0;
static volatile int64_t s_voltage_period_us = 0;
static volatile int64_t s_current_period_us = 0;

static volatile int s_sel_mode = 0; // 0 = Voltage, 1 = Current
static volatile bool s_sel_settled = false;
static int64_t s_last_sel_toggle = 0;

static void IRAM_ATTR cf_isr_handler(void *arg) {
    (void)arg;
    int64_t now = esp_timer_get_time();
    int64_t diff = now - s_last_cf_time;
    if (diff > 50) {
        s_cf_period_us = diff;
        s_last_cf_time = now;
        s_cf_pulse_count++;
    }
}

static void IRAM_ATTR cf1_isr_handler(void *arg) {
    (void)arg;
    int64_t now = esp_timer_get_time();
    int64_t diff = now - s_last_cf1_time;
    if (diff > 50) {
        s_last_cf1_time = now;
        if (s_sel_settled) {
            if (s_sel_mode == 0) {
                s_voltage_period_us = diff;
            } else {
                s_current_period_us = diff;
            }
        }
    }
}

static bool s_bl0937_initialized = false;

esp_err_t bl0937_init(gpio_num_t cf_pin, gpio_num_t cf1_pin, gpio_num_t sel_pin) {
    if (s_bl0937_initialized) {
        return ESP_OK;
    }
    s_cf_pin = cf_pin;
    s_cf1_pin = cf1_pin;
    s_sel_pin = sel_pin;

    ESP_LOGI(TAG, "Init BL0937: CF=GPIO%d, CF1=GPIO%d, SEL=GPIO%d", cf_pin, cf1_pin, sel_pin);

    if (sel_pin != GPIO_NUM_NC) {
        gpio_config_t sel_conf = {
            .pin_bit_mask = (1ULL << sel_pin),
            .mode = GPIO_MODE_OUTPUT,
            .pull_up_en = GPIO_PULLUP_DISABLE,
            .pull_down_en = GPIO_PULLDOWN_DISABLE,
            .intr_type = GPIO_INTR_DISABLE,
        };
        gpio_config(&sel_conf);
        gpio_set_level(sel_pin, 0);
        s_sel_mode = 0;
        s_sel_settled = true;
        s_last_sel_toggle = esp_timer_get_time();
    }

    gpio_config_t pulse_conf = {
        .pin_bit_mask = (1ULL << cf_pin) | (1ULL << cf1_pin),
        .mode = GPIO_MODE_INPUT,
        .pull_up_en = GPIO_PULLUP_ENABLE,
        .pull_down_en = GPIO_PULLDOWN_DISABLE,
        .intr_type = GPIO_INTR_POSEDGE,
    };
    gpio_config(&pulse_conf);

    gpio_install_isr_service(0);
    gpio_isr_handler_add(cf_pin, cf_isr_handler, NULL);
    gpio_isr_handler_add(cf1_pin, cf1_isr_handler, NULL);

    s_bl0937_initialized = true;
    return ESP_OK;
}

esp_err_t power_meter_init(gpio_num_t rx_pin, gpio_num_t tx_pin, uint32_t baud_rate) {
    (void)rx_pin;
    (void)tx_pin;
    (void)baud_rate;
    return bl0937_init((gpio_num_t)8, (gpio_num_t)6, (gpio_num_t)7);
}

esp_err_t power_meter_read(ac_measurement_t *out_data) {
    if (!out_data) return ESP_ERR_INVALID_ARG;

    int64_t now = esp_timer_get_time();

    if (s_sel_pin != GPIO_NUM_NC) {
        if (now - s_last_sel_toggle > 2000000LL) {
            s_sel_mode = !s_sel_mode;
            gpio_set_level(s_sel_pin, s_sel_mode);
            s_sel_settled = false;
            s_last_sel_toggle = now;
        } else if (!s_sel_settled && (now - s_last_sel_toggle > 200000LL)) {
            s_sel_settled = true;
        }
    }

    if (now - s_last_cf_time > 2500000LL) {
        s_cf_period_us = 0;
    }
    if (now - s_last_cf1_time > 2500000LL) {
        if (s_sel_mode == 0) s_voltage_period_us = 0;
        else s_current_period_us = 0;
    }

    if (s_cf_period_us > 0) {
        out_data->power_w = 1350000.0f / (float)s_cf_period_us;
        if (out_data->power_w < 0.5f) out_data->power_w = 0.0f;
    } else {
        out_data->power_w = 0.0f;
    }

    if (s_voltage_period_us > 0) {
        out_data->voltage_v = 2450000.0f / (float)s_voltage_period_us;
    } else {
        out_data->voltage_v = 230.0f;
    }

    if (s_current_period_us > 0 && out_data->power_w > 0.5f) {
        out_data->current_a = 125000.0f / (float)s_current_period_us;
        if (out_data->current_a < 0.02f) out_data->current_a = 0.0f;
    } else {
        out_data->current_a = 0.0f;
    }

    out_data->raw_pulses = s_cf_pulse_count;
    out_data->energy_kwh = (float)s_cf_pulse_count * 0.0003125f;

    if (out_data->voltage_v > 50.0f && out_data->current_a > 0.05f) {
        out_data->power_factor = out_data->power_w / (out_data->voltage_v * out_data->current_a);
        if (out_data->power_factor > 1.0f) out_data->power_factor = 1.0f;
    } else {
        out_data->power_factor = 1.0f;
    }

    return ESP_OK;
}
