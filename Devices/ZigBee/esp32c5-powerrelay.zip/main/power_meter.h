/**
 * @file power_meter.h
 * @brief AC Power Metering Driver for BL0937 (Voltage, Current, Active Power, Energy)
 */

#pragma once

#include "esp_err.h"
#include "driver/gpio.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
    float voltage_v;     // Напряжение (В)
    float current_a;     // Сила тока (А)
    float power_w;       // Активная мощность (Вт)
    float energy_kwh;    // Суммарная энергия (кВт⋅ч)
    float power_factor;  // Коэффициент мощности (0.0 - 1.0)
    uint32_t raw_pulses; // Счетчик импульсов энергии
} ac_measurement_t;

// BL0937 Pulse Counting
esp_err_t bl0937_init(gpio_num_t cf_pin, gpio_num_t cf1_pin, gpio_num_t sel_pin);

// UART-based chips
esp_err_t power_meter_init(gpio_num_t rx_pin, gpio_num_t tx_pin, uint32_t baud_rate);

// Unified read
esp_err_t power_meter_read(ac_measurement_t *out_data);

#ifdef __cplusplus
}
#endif
