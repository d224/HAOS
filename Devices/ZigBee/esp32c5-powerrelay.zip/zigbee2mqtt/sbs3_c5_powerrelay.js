/**
 * Home Assistant OS - Zigbee2MQTT External Converter
 * Device: SBS3-C5-PowerRelay by ZigbeeDud (ESP32-C5 SBS3 Replacement)
 * Place this file into /config/zigbee2mqtt/sbs3_c5_powerrelay.js
 */

const fz = require('zigbee-herdsman-converters/converters/fromZigbee');
const tz = require('zigbee-herdsman-converters/converters/toZigbee');
const exposes = require('zigbee-herdsman-converters/lib/exposes');
const reporting = require('zigbee-herdsman-converters/lib/reporting');
const e = exposes.presets;
const ea = exposes.access;

const definition = {
    zigbeeModel: ['SBS3-C5-PowerRelay'],
    model: 'SBS3-C5-PowerRelay',
    vendor: 'ZigbeeDud',
    description: 'Умное реле SBS3 на базе ESP32-C5 mini v1 с контролем температуры 1-Wire (DS18B20) и замером мощности AC',
    fromZigbee: [
        fz.on_off,
        fz.electrical_measurement,
        fz.metering,
        fz.temperature,
    ],
    toZigbee: [
        tz.on_off,
    ],
    exposes: [
        e.switch().setAccess('state', ea.STATE_SET),
        e.power().withUnit('W').withDescription('Потребляемая активная мощность'),
        e.voltage().withUnit('V').withDescription('Напряжение сети переменного тока'),
        e.current().withUnit('A').withDescription('Сила тока нагрузки'),
        e.energy().withUnit('kWh').withDescription('Суммарная потребленная энергия'),
        e.temperature().withUnit('°C').withDescription('Температура внешнего 1-Wire датчика DS18B20'),
        e.numeric('rssi', ea.STATE).withUnit('dBm').withDescription('Уровень принимаемого радиосигнала Zigbee (RSSI)'),
        e.numeric('lqi', ea.STATE).withDescription('Качество связи Zigbee Link Quality (LQI 0-255)'),
        e.linkquality(),
    ],
    endpoint: (device) => {
        return {
            default: 1,
            temperature: 2,
        };
    },
    configure: async (device, coordinatorEndpoint, logger) => {
        const ep1 = device.getEndpoint(1);
        const ep2 = device.getEndpoint(2);

        // Bindings for Endpoint 1 (Relay & Power Measurement)
        await reporting.bind(ep1, coordinatorEndpoint, [
            'genOnOff',
            'haElectricalMeasurement',
            'seMetering',
        ]);
        await reporting.onOff(ep1);
        await reporting.rmsVoltage(ep1, { min: 2, max: 300, change: 1 });
        await reporting.rmsCurrent(ep1, { min: 1, max: 60, change: 50 });
        await reporting.activePower(ep1, { min: 1, max: 60, change: 5 });
        await reporting.currentSummationDelivered(ep1, { min: 60, max: 3600, change: 1 });

        // Bindings for Endpoint 2 (DS18B20 Temperature)
        if (ep2) {
            await reporting.bind(ep2, coordinatorEndpoint, ['msTemperatureMeasurement']);
            await reporting.temperature(ep2, { min: 5, max: 300, change: 50 });
        }
    },
};

module.exports = definition;
