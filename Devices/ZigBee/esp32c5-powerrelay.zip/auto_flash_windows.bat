@echo off
chcp 65001 >nul
echo ==============================================================
echo [ZigbeeDud] Автоматический поиск порта и прошивка ESP32-C5
echo ==============================================================

:: Поиск COM-порта через PowerShell
echo [*] Поиск подключенной платы ESP32-C5...
for /f "usebackq tokens=*" %%P in (`powershell -NoProfile -Command "Get-CimInstance Win32_SerialPort | Where-Object { $_.Description -match 'USB|Serial|CP210|CH340|FTDI|Espressif' } | Select-Object -ExpandProperty DeviceID -First 1"`) do set AUTOPORT=%%P

if "%AUTOPORT%"=="" (
    echo [!] Плата не определена автоматически.
    echo Пожалуйста, проверьте подключение USB-кабеля или введите порт вручную:
    set /p AUTOPORT="Введите порт (например COM3): "
)

echo [*] Обнаружена плата на порту: %AUTOPORT%
echo [*] Запуск сборки и прошивки в автоматическом режиме...

:: Проверка переменной IDF_PATH
if not defined IDF_PATH (
    if exist "C:\Espressif\idf_cmd_init.bat" call "C:\Espressif\idf_cmd_init.bat"
    if exist "C:\esp\esp-idf\export.bat" call "C:\esp\esp-idf\export.bat"
    if exist "C:\Espressif\frameworks\esp-idf\export.bat" call "C:\Espressif\frameworks\esp-idf\export.bat"
)

call idf.py -p %AUTOPORT% flash monitor
pause
